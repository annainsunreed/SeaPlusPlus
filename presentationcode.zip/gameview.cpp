#include <QLineF>
#include <QPointF>
#include <QCursor>
#include <QMediaPlayer>
#include <QImage>
#include <stdlib.h>
#include "player.h"
#include <QPixmap>
#include <QGraphicsPixmapItem>
//#include "rocks.h"
#include "gameview.h"
#include "projectile.h"

GameView::GameView(QWidget *parent): QGraphicsView(parent){
    player = new Player(QPixmap(":/pictures/submarine.png"));
    player->setFlag(QGraphicsItem::ItemIsFocusable,true);
    player->setFocus();
    player->setPos(300,200);
    scene = new QGraphicsScene(this);
    scene->addItem(player);

    setScene(scene);
    setSceneRect(scene->sceneRect());
    setWindowTitle("SeaPlusPlus Wars");
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    setMouseTracking(true);
}

void GameView::keyPressEvent(QKeyEvent *event){
    // if esc is pressed, close the game
    if (event->key() == Qt::Key_Escape)
    close();

    // other wise, pass keyboard event to scene which passes it to focused item (which is the player)
    QGraphicsView::keyPressEvent(event);
}

void GameView::mouseMoveEvent(QMouseEvent *event)
{
    QPointF pt1(player->getOrigin()); //change point to object from player of x/y_previous
        QPointF pt2(event->pos());
        QLineF line(pt1,pt2);
        double angle = -1 * line.angle();

        player->setRotation(angle);
        player->setAngle(angle);
}


void GameView::mousePressEvent(QMouseEvent *event)
{
    projectile* Projectile = new projectile();
    Projectile->setPos(player->getOrigin());
    Projectile->setRotation(player->getAngle());
    scene->addItem(Projectile);
}

void GameView::mouseDoubleClickEvent(QMouseEvent *event)
{

}



