/*
#include "enemy.h"
#include <QPixmap>
#include <QTimer>
#include <qmath.h>
#include <QPointF>
#include <QLineF>
#include "gameview.h"
#include <cstdarg>

extern GameView* game;


enemy::enemy(QGraphicsItem *parent)
{
    //setPixmap(QPixmap("")); add enemy ship

    //points<<QPointF( , )<< QPointF(,)<< QPointF(, ) <<QPointF(,);
    point_index = 0;
    goal = points[0];

    // speed = 100;
}





void enemy::pathturn(QPointF p)
{
    QLineF ln(pos(),p);
    setRotation(-1*ln.angle());
}

void enemy::setspeed(int s)
{
    speed = s; //update for each level
}

void enemy::move()
{
    int step_size = 40;
    double degree = rotation();

    double dy = step_size*qSin(qDegreesToRadians(degree));
    double dx = step_size*qCos(qDegreesToRadians(degree));

    setPos(x()+dx, y()+dy);
}
*/
