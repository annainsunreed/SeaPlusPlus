#include"playingwindow.h"
#include"gameview.h"

PlayingWindow::PlayingWindow(QWidget *parent) : QWidget(parent) {

label = new QLabel("              Select Difficulty");
QFont labelFont = label->font();
labelFont.setPointSize(40);
labelFont.setBold(true);
label->setFont(labelFont);

layout = new QGridLayout();
level_one_button=new QPushButton("Easy");
level_two_button=new QPushButton("Medium");
level_three_button=new QPushButton("Hard");
back_button = new QPushButton("Back");

QVBoxLayout* miniLayoutVert = new QVBoxLayout;
miniLayoutVert->addWidget(label);
//layout->addWidget(label, 0,2);

QHBoxLayout* miniLayoutHo = new QHBoxLayout;
miniLayoutHo->addWidget(level_one_button);
miniLayoutHo->addWidget(level_two_button);
miniLayoutHo->addWidget(level_three_button);

miniLayoutVert->addLayout(miniLayoutHo);
//layout->addLayout(miniLayoutHo, 1, 2);
layout->addLayout(miniLayoutVert, 1, 2);
layout->addWidget(back_button, 2, 2);
setLayout(layout);

connect(back_button,SIGNAL(pressed()),this,SLOT(handlePlayWinBackPressed()));
connect(level_one_button,SIGNAL(clicked()),this, SLOT(playLevelOne()));
connect(level_two_button,SIGNAL(clicked()),this, SLOT(playLevelTwo()));
connect(level_three_button,SIGNAL(clicked()),this, SLOT(playLevelThree()));
}

PlayingWindow::~PlayingWindow(){}

void PlayingWindow::handlePlayWinBackPressed(){
    emit playWinBackPressed();
}

void PlayingWindow::playLevelOne(){
    game=new GameView();
    game->setFixedSize(1280,720);
    game->show();
    //game->showFullScreen();
    game->placeRock(256,0,20,500,0);
    game->placeRock(768,0,20,500,0);
    game->placeRock(512,700,20,500,180);
    game->placeRock(1024,700,20,500,180);
}

void PlayingWindow::playLevelTwo(){
    game=new GameView();
    //game->showFullScreen();
    game->setFixedSize(1280,720);
    game->show();
}

void PlayingWindow::playLevelThree(){
    game=new GameView();
    //game->showFullScreen();
    game->setFixedSize(1280,720);
    game->show();
}
