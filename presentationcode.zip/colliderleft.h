#ifndef COLLIDERLEFT_H
#define COLLIDERLEFT_H

#include <QGraphicsRectItem>
#include <QString>
class ColliderLeft: public QGraphicsRectItem
{
public:
    ColliderLeft(QGraphicsItem *parent=0);
};

#endif // COLLIDERLEFT_H
