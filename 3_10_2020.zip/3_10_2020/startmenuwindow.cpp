#include "startmenuwindow.h"

StartMenuWindow::StartMenuWindow(QWidget *parent) : QWidget(parent) {

   // initialize start menu buttons
    title=new QLabel("SeaPlusPlus");

    QFont titleFont = title->font();
    titleFont.setPointSize(20);
    title->setFont(titleFont);

   startButton = new QPushButton("start");
   quitButton = new QPushButton("quit");
   tutorialButton = new QPushButton("tutorial");
   soundPlayButton = new QPushButton("play music");
   soundPauseButton = new QPushButton("pause music");
   QVBoxLayout* miniLayoutTop = new QVBoxLayout;
   QVBoxLayout* miniLayoutBottom = new QVBoxLayout;

   // set layout
   startMenuLayout = new QGridLayout();
   startMenuLayout->addWidget(title,0,2);
   startMenuLayout->addLayout(miniLayoutTop, 2, 2);
   startMenuLayout->addLayout(miniLayoutBottom, 3, 0);
   miniLayoutTop->addWidget(startButton);
   miniLayoutTop->addWidget(tutorialButton);
   startMenuLayout->addWidget(quitButton, 3, 3);
   miniLayoutBottom->addWidget(soundPlayButton);
   miniLayoutBottom->addWidget(soundPauseButton);

   setLayout(startMenuLayout);

   connect(startButton,SIGNAL(pressed()),this,SLOT(handleStartButtontPressed()));
   connect(tutorialButton,SIGNAL(pressed()),this,SLOT(handleTutorialButtonPressed()));
   connect(quitButton,SIGNAL(pressed()),this,SLOT(handleQuitButtonPressed()));
   connect(soundPlayButton, SIGNAL(clicked()),this, SLOT(handleSoundPlayButtonPressed()));
   connect(soundPauseButton, SIGNAL(clicked()),this, SLOT(handleSoundPauseButtonPressed()));
}

void StartMenuWindow::handleStartButtontPressed(){
    emit startButtonPressed();
}

void StartMenuWindow::handleTutorialButtonPressed(){
    emit tutorialButtonPressed();
}

void StartMenuWindow::handleQuitButtonPressed(){
    emit quitButtonPressed();
}

void StartMenuWindow::handleSoundPlayButtonPressed(){
    emit soundPlayButtonPressed();
}

void StartMenuWindow::handleSoundPauseButtonPressed(){
    emit soundPauseButtonPressed();
}


StartMenuWindow::~StartMenuWindow(){}


