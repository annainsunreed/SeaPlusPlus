#include "enemy.h"
#include <QPixmap>
#include <QTimer>
#include <qmath.h>
#include <QPointF>
#include <QLineF>
#include "gameview.h"

extern GameView* game;


enemy::enemy(QVector<QPointF> paths, int _level, QGraphicsItem * parent)
{
    setPixmap(QPixmap(":/pictures/submarine.png"));

    //easy path
    QPointF e1 = QPointF(1152, 80);
    QPointF e2 = QPointF(896, 80);
    QPointF e3 = QPointF(896, 580);
    QPointF e4 = QPointF(640, 580);
    QPointF e5 = QPointF(684, 80);
    QPointF e6 = QPointF(384, 80);
    QPointF e7 = QPointF(384, 580);
    QPointF e8 = QPointF(128, 580);
    QPointF e9 = QPointF(128, 20);

    patheasy.push_back(e1);
    patheasy.push_back(e2);
    patheasy.push_back(e3);
    patheasy.push_back(e4);
    patheasy.push_back(e5);
    patheasy.push_back(e6);
    patheasy.push_back(e7);
    patheasy.push_back(e8);
    patheasy.push_back(e9);

    //medium path
    QPointF m1 = QPointF(160, 550);
    QPointF m2 = QPointF(160, 330);
    QPointF m3 = QPointF(1120, 330);
    QPointF m4 = QPointF(1120, 110);
    QPointF m5 = QPointF(20, 110);

    pathmedium.push_back(m1);
    pathmedium.push_back(m2);
    pathmedium.push_back(m3);
    pathmedium.push_back(m4);
    pathmedium.push_back(m5);

    //hard path
    QPointF h1 = QPointF(480, 330);
    QPointF h2 = QPointF(480, 110);
    QPointF h3 = QPointF(1110,110);
    QPointF h4 = QPointF(1110,550);
    QPointF h5 = QPointF(160, 550);
    QPointF h6 = QPointF(160, 20);

    pathhard.push_back(h1);
    pathhard.push_back(h2);
    pathhard.push_back(h3);
    pathhard.push_back(h4);
    pathhard.push_back(h5);
    pathhard.push_back(h6);

    index = 0;
    goaleasy = patheasy[0];
    goalmedium = pathmedium[0];
    goalhard = pathhard[0];

    level = _level;
    if(level == 1)
    {
    pathturn(goaleasy);
    QTimer* easytimer = new QTimer(this);
    connect(easytimer, SIGNAL(timeout()), this, SLOT(moveeasy()));
    easytimer->start(100);
    }

    if(level == 2)
    {
    pathturn(goalmedium);
    QTimer* mediumtimer = new QTimer(this);
    connect(mediumtimer, SIGNAL(timeout()), this, SLOT(movemedium()));
    mediumtimer->start(100);
    }

    if (level==3)
    {
    pathturn(goalhard);
    QTimer* hardtimer = new QTimer(this);
    connect(hardtimer, SIGNAL(timeout()), this, SLOT(movehard()));
    hardtimer->start(100);
    }
    //different timers for different levels
}





void enemy::pathturn(QPointF p)
{
    QLineF ln(pos(),p);
    setRotation(-1*ln.angle());  //setRotation measures clockwise
}

void enemy::movetimer()
{

}
/*
void enemy::setspeed(int s)
{
    speed = s; //update for each level
}
*/

void enemy::moveeasy() //pass vector path and "patheasy"
{
    QLineF ln(pos(), goaleasy);
    if (ln.length() < 6)
    {
        index++;
        if (index >= patheasy.size())
        {
           return; //could reverse vector
        }
        goaleasy=patheasy[index];
        pathturn(goaleasy);
    }
    int step_size = 10;
    double degree = rotation();

    double dy = step_size*qSin(qDegreesToRadians(degree));
    double dx = step_size*qCos(qDegreesToRadians(degree));

    setPos(x()+dx, y()+dy);
   }


void enemy::movemedium() //pass vector path and "patheasy"
{
    QLineF ln(pos(), goalmedium);
    if (ln.length() < 6)
    {
        index++;
        if (index >= pathmedium.size())
        {
           return; //could reverse vector
        }
        goalmedium=pathmedium[index];
        pathturn(goalmedium);
    }
    int step_size = 10;
    double degree = rotation();

    double dy = step_size*qSin(qDegreesToRadians(degree));
    double dx = step_size*qCos(qDegreesToRadians(degree));

    setPos(x()+dx, y()+dy);
}
void enemy::movehard() //pass vector path and "patheasy"
{
    QLineF ln(pos(), goalhard);
    if (ln.length() < 6)
    {
        index++;
        if (index >= pathhard.size())
        {
           return; //could reverse vector
        }
        goalhard=pathhard[index];
        pathturn(goalhard);
    }
    int step_size = 10;
    double degree = rotation();

    double dy = step_size*qSin(qDegreesToRadians(degree));
    double dx = step_size*qCos(qDegreesToRadians(degree));

    setPos(x()+dx, y()+dy);
}

