#ifndef GAMEVIEW_H
#define GAMEVIEW_H

#include <QGraphicsView>
#include <QGraphicsScene>
#include <QMouseEvent>
#include <QResizeEvent>
#include <QKeyEvent>
#include "player.h"
#include "enemy.h"

class GameView;
extern GameView * game;

class GameView: public QGraphicsView{
    Q_OBJECT
public:
    GameView(QWidget * parent=0);

    void keyPressEvent(QKeyEvent * event);
    void mouseMoveEvent(QMouseEvent *event);
    void mousePressEvent(QMouseEvent* event);
    void mouseDoubleClickEvent(QMouseEvent* event);
    void addenemyeasy();
    void addenemymedium();
    void addenemyhard();


    void placeRocks();
    void placeRock(int x, int y, int width, int length, int rotation);

    QGraphicsScene * scene;

    Player * player;

    enemy* Enemy;
    int point_index = 0;
    QPointF goal;
    QVector<QPointF> paths;


    QVector<QPointF> patheasy;
    QVector<QPointF> pathmedium;
    QVector<QPointF> pathhard;

public slots:
    void showGGWindow();
    //void check_count();


private:
    int enemy_count;

};

#endif // GAMEVIEW_H
