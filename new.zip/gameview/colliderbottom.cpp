#include "colliderbottom.h"

ColliderBottom::ColliderBottom(QGraphicsItem *parent): QGraphicsRectItem(parent){

}
