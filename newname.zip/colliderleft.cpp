#include "colliderleft.h"

ColliderLeft::ColliderLeft(QGraphicsItem *parent): QGraphicsRectItem(parent){

}
