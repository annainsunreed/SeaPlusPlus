#include "player.h"
//#include "rocks.h"
#include "gameview.h"
#include <QDebug>
#include <QPixmap>
#include <QGraphicsPixmapItem>

Player::Player(const QPixmap &pixmap): QObject(), QGraphicsPixmapItem(pixmap)
{
    x_previous = pos().x();
    y_previous = pos().y();
    health = 1;

    setTransformOriginPoint(111,41);
}

void Player::keyPressEvent(QKeyEvent *event)
{
    if (
            event->key() == Qt::Key_W ||
            event->key() == Qt::Key_A ||
            event->key() == Qt::Key_S ||
            event->key() == Qt::Key_D
       )
    {
        keysPressed.insert(event->key());
    }

    int step_size = 10;

    if (keysPressed.size() == 1){
        switch (event->key())
        {
        case Qt::Key_W:
            setPos(x(), y()-step_size);
            break;

        case Qt::Key_A:
            setPos(x()-step_size, y());
            break;

        case Qt::Key_S:
            setPos(x(), y()+step_size);
            break;

        case Qt::Key_D:
            setPos(x()+step_size, y());
            break;
        }
    }

    if (keysPressed.size() > 1)
    {
        if (keysPressed.contains(Qt::Key_W) && keysPressed.contains(Qt::Key_A))
        {
            setPos(x()-step_size, y()-step_size);
        }
        if (keysPressed.contains(Qt::Key_W) && keysPressed.contains(Qt::Key_D))
        {
            setPos(x()+step_size, y()-step_size);
        }
        if (keysPressed.contains(Qt::Key_S) && keysPressed.contains(Qt::Key_A))
        {
            setPos(x()-step_size, y()+step_size);
        }
        if (keysPressed.contains(Qt::Key_S) && keysPressed.contains(Qt::Key_D))
        {
            setPos(x()+step_size, y()+step_size);
        }
    }
    x_previous = pos().x();
    y_previous = pos().y();
}

void Player::keyReleaseEvent(QKeyEvent *event){
    keysPressed.remove(event->key());
}

void Player::setAngle(double a){
    angle = a;
}

double Player::getAngle() const{
    return (angle);
}

QPointF Player::getOrigin(){
    return mapToScene(transformOriginPoint());
}

