﻿#include"playingwindow.h"
#include"gameview.h"

PlayingWindow::PlayingWindow(QWidget *parent) : QWidget(parent) {

label = new QLabel("Difficulty");
layout = new QVBoxLayout();
level_one_button=new QPushButton("Easy");
level_two_button=new QPushButton("Medium");
level_three_button=new QPushButton("Hard");
back_button = new QPushButton("Back");
layout->addWidget(label);
layout->addWidget(level_one_button);
layout->addWidget(level_two_button);
layout->addWidget(level_three_button);
layout->addWidget(back_button);
setLayout(layout);

connect(back_button,SIGNAL(pressed()),this,SLOT(handlePlayWinBackPressed()));
connect(level_one_button,SIGNAL(clicked()),this, SLOT(playLevelOne()));
connect(level_two_button,SIGNAL(clicked()),this, SLOT(playLevelTwo()));
connect(level_three_button,SIGNAL(clicked()),this, SLOT(playLevelThree()));
}

PlayingWindow::~PlayingWindow(){}

void PlayingWindow::handlePlayWinBackPressed(){
    emit playWinBackPressed();
}

void PlayingWindow::playLevelOne(){
    points.clear(); //clearing path

    game=new GameView();
    game->setFixedSize(1280,660);
    game->show();
    //game->showFullScreen();

    QPointF p1 = QPointF(1152, 80);
    QPointF p2 = QPointF(896, 80);
    QPointF p3 = QPointF(896, 580);
    QPointF p4 = QPointF(640, 580);
    QPointF p5 = QPointF(684, 80);
    QPointF p6 = QPointF(384, 80);
    QPointF p7 = QPointF(384, 580);
    QPointF p8 = QPointF(128, 580);
    QPointF p9 = QPointF(128, 20);

    points.push_back(p1);
    points.push_back(p2);
    points.push_back(p3);
    points.push_back(p4);
    points.push_back(p5);
    points.push_back(p6);
    points.push_back(p7);
    points.push_back(p8);
    points.push_back(p9);

    game->placeRock(256,0,20,500,0);
    game->placeRock(768,0,20,500,0);
    game->placeRock(512,700,20,500,180);
    game->placeRock(1024,700,20,500,180);
}

void PlayingWindow::playLevelTwo(){
    points.clear(); //clearing path

    game=new GameView();
    //game->showFullScreen();
    game->setFixedSize(1280,660);
    game->show();


    QPointF p1 = QPointF(160, 550);
    QPointF p2 = QPointF(160, 330);
    QPointF p3 = QPointF(1120, 330);
    QPointF p4 = QPointF(1120, 110);
    QPointF p5 = QPointF(20, 110);

    points.push_back(p1);
    points.push_back(p2);
    points.push_back(p3);
    points.push_back(p4);
    points.push_back(p5);

    game->placeRock(0, 220, 960, 20, 0);
    game->placeRock(1280, 440, 960, 20, 180);

}

void PlayingWindow::playLevelThree(){
    points.clear(); //clearing path

    game=new GameView();
    //game->showFullScreen();
    game->setFixedSize(1280,660);
    game->show();
/*
    QPointF p1 = QPointF(160, 550);
    QPointF p2 = QPointF(160, 330);
    QPointF p3 = QPointF(1120, 330);
    QPointF p4 = QPointF(1120, 110);
    QPointF p5 = QPointF(20, 110);
    QPointF p6 = QPointF(160, 550);
 */

    game->placeRock(320, 0, 20, 440, 0);
    game->placeRock(320, 440, 620, 20, 0);
    game->placeRock(940, 440, 20, 200, 180);
    game->placeRock(940, 220, 300, 20, 180);
}
