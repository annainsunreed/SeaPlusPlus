/*
#ifndef ENEMY_H
#define ENEMY_H

#include <QGraphicsPixmapItem>
#include <QObject>
#include <QList>
#include <QPointF>

class enemy: public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
public:
    enemy(const QPixmap &pixmap);
    void followplayer();

    void setspeed(int s);
    void setgoal(const QPointF& pt);

    public slots:
        void move();

private:
        QList<QPointF> points;
        QPointF dest;
        int point_index;

        QPointF goal;
        int speed;
        int health;
};

#endif // ENEMY_H
*/
