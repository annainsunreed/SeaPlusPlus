#ifndef COLLIDERTOP_H
#define COLLIDERTOP_H

#include <QGraphicsRectItem>
#include <QString>
class ColliderTop: public QGraphicsRectItem
{
public:
    ColliderTop(QGraphicsItem *parent=0);
};

#endif // COLLIDERTOP_H
