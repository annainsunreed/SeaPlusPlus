#include "collidertop.h"

ColliderTop::ColliderTop(QGraphicsItem *parent): QGraphicsRectItem(parent){

}
