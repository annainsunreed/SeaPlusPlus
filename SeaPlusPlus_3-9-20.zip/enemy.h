/*
#ifndef ENEMY_H
#define ENEMY_H

#include <QGraphicsPixmapItem>
#include <QObject>
#include <QList>
#include <QPointF>


class enemy: public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
public:
    enemy(QGraphicsItem* parent = 0);

    void pathturn(QPointF p);

    void setspeed(int s);

    public slots:
        void move();

private:
        QList<QPointF> points;
        QPointF goal;
        int point_index;

        int speed;
        int health;
};

#endif // ENEMY_H


*/
