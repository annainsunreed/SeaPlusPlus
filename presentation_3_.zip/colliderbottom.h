#ifndef COLLIDERBOTTOM_H
#define COLLIDERBOTTOM_H

#include <QGraphicsRectItem>
#include <QString>
class ColliderBottom: public QGraphicsRectItem
{
public:
    ColliderBottom(QGraphicsItem *parent=0);
};

#endif // COLLIDERBOTTOM_H
