#ifndef PROJECTILE_H
#define PROJECTILE_H

#include <QGraphicsPixmapItem>
#include <QObject>
#include <QGraphicsItem>

class projectile: public QObject, public QGraphicsPixmapItem
{
Q_OBJECT
public:
    projectile(QGraphicsItem* parent = 0);
public slots:
    void fly();
};

#endif // PROJECTILE_H
