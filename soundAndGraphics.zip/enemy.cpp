#include "enemy.h"
#include <QPixmap>
#include <QTimer>
#include <qmath.h>
#include <QPointF>
#include <QLineF>
#include "gameview.h"

extern GameView* game;
/*
enemy::enemy(const QPixmap &pixmap)
{
    setPixmap(QPixmap(""));
    //setTransformOriginPoint(); //set to center of image pixels
    health = 1; // if bullet collides with them, subtract health
}


void enemy::followplayer()
{
    QLineF ln(game->player->getOrigin(),scenePos());
    ln.setLength(350);
    setgoal(ln.p2());
}

void enemy::setspeed(int s)
{
    speed = s;
}

void enemy::setgoal(const QPointF &pt)
{
    goal = pt;
}

void enemy::move()
{
    QLineF ln(scenePos(), goal);
    ln.setLength(speed);
    setRotation(-1* ln.angle());

    double dx =ln.dx();
    double dy = ln.dy();
    setPos(x()+dx, y()+dy);
}
*/


