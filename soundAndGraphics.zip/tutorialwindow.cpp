#include"tutorialwindow.h"

TutorialWindow::TutorialWindow(QWidget *parent) : QWidget(parent) {
   title = new QLabel("Here are the SeaPlusPlus instuctions:");

   QFont titleFont = title->font();
   titleFont.setPointSize(30);
   title->setFont(titleFont);

   layout = new QVBoxLayout;

   how_to=new QLabel(this);
   QFont instructionsFont = how_to->font();
   instructionsFont.setPointSize(20);
   how_to->setFont(instructionsFont);
   back_button=new QPushButton("back");
   QString how_to_txt(QString("-move with the W, A, S and D keys<br>") +
                        QString("-shoot by clicking with your mouse<br>") +
                        QString("-win by killing enemy ships<br>") +
                        QString("*turn up your volume (there is music!)")
                        );
   how_to->setText(how_to_txt);
   layout->addWidget(title);
   layout->addWidget(how_to);
   layout->addWidget(back_button);
   setLayout(layout);

   connect(back_button,SIGNAL(pressed()),this,SLOT(handleTutorialWinBackPressed()));
}

TutorialWindow::~TutorialWindow(){}

void TutorialWindow::handleTutorialWinBackPressed(){
    emit tutorialWinBackPressed();
}
