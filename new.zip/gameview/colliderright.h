#ifndef COLLIDERRIGHT_H
#define COLLIDERRIGHT_H

#include <QGraphicsRectItem>
#include <QString>
class ColliderRight: public QGraphicsRectItem
{
public:
    ColliderRight(QGraphicsItem *parent=0);
};

#endif // COLLIDERRIGHT_H
