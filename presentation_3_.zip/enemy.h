#ifndef ENEMY_H
#define ENEMY_H

#include <QGraphicsPixmapItem>
#include <QObject>
#include <QVector>
#include <QPointF>


class enemy: public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
public:
    enemy(QVector<QPointF> paths, int _level, QGraphicsItem* parent = 0);

    void pathturn(QPointF p);

    void movetimer();


    //void setspeed(int s);

    public slots:
        void moveeasy(); //pass QVector path
        void movemedium();
        void movehard();
private:
        QVector<QPointF> patheasy;
        QVector<QPointF> pathmedium;
        QVector<QPointF> pathhard;
        QPointF goaleasy;
        QPointF goalmedium;
        QPointF goalhard;

        int index;
        int level;

        //int speed;
        int health;
};

#endif // ENEMY_H

