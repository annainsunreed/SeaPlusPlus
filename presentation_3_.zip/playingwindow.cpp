﻿#include"playingwindow.h"
#include"gameview.h"

PlayingWindow::PlayingWindow(QWidget *parent) : QWidget(parent) {

label = new QLabel("Difficulty");
layout = new QVBoxLayout();
level_one_button=new QPushButton("Easy");
level_two_button=new QPushButton("Medium");
level_three_button=new QPushButton("Hard");
back_button = new QPushButton("Back");
layout->addWidget(label);
layout->addWidget(level_one_button);
layout->addWidget(level_two_button);
layout->addWidget(level_three_button);
layout->addWidget(back_button);
setLayout(layout);

connect(back_button,SIGNAL(pressed()),this,SLOT(handlePlayWinBackPressed()));
connect(level_one_button,SIGNAL(clicked()),this, SLOT(playLevelOne()));
connect(level_two_button,SIGNAL(clicked()),this, SLOT(playLevelTwo()));
connect(level_three_button,SIGNAL(clicked()),this, SLOT(playLevelThree()));
}

PlayingWindow::~PlayingWindow(){}

void PlayingWindow::handlePlayWinBackPressed(){
    emit playWinBackPressed();
}

void PlayingWindow::playLevelOne(){ 

    game=new GameView();
    game->setFixedSize(1280,660);
    game->show();
    //game->showFullScreen();

    game->placeRock(256,0,20,500,0);
    game->placeRock(768,0,20,500,0);
    game->placeRock(512,700,20,500,180);
    game->placeRock(1024,700,20,500,180);

    //game->addenemy(1140, 500);
    game->addenemyeasy();
}

void PlayingWindow::playLevelTwo(){

    game=new GameView();
    //game->showFullScreen();
    game->setFixedSize(1280,660);
    game->show();

    game->placeRock(0, 220, 960, 20, 0);
    game->placeRock(1280, 440, 960, 20, 180);

    game->addenemymedium();

}

void PlayingWindow::playLevelThree(){

    game=new GameView();
    //game->showFullScreen();
    game->setFixedSize(1280,660);
    game->show();


    game->placeRock(320, 0, 20, 440, 0);
    game->placeRock(320, 440, 620, 20, 0);
    game->placeRock(940, 440, 20, 200, 180);
    game->placeRock(940, 240, 300, 20, 180);

    game->addenemyhard();
}
