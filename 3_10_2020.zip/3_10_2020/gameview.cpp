#include <QLineF>
#include <QPointF>
#include <QCursor>
#include <QMediaPlayer>
#include <QImage>
#include <stdlib.h>
#include "player.h"
#include <QPixmap>
#include <QGraphicsPixmapItem>
#include "rocks.h"
#include "gameview.h"
#include "projectile.h"
#include "enemy.h"

GameView::GameView(QWidget *parent): QGraphicsView(parent){

    scene = new QGraphicsScene(this);
    setCursor(QCursor(Qt::CrossCursor));
    placeRocks();

    player = new Player(QPixmap(":/pictures/submarine.png"));
    player->setFlag(QGraphicsItem::ItemIsFocusable,true);
    player->setFocus();
    player->setPos(70,70);
    scene->addItem(player);



    QImage * img = new QImage(":/pictures/sea.png");
    QBrush bg_brush(*img);
    scene->setBackgroundBrush(bg_brush);


    setScene(scene);
    setSceneRect(scene->sceneRect());
    setWindowTitle("SeaPlusPlus Wars");
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    setMouseTracking(true);
    connect(player,SIGNAL(gameOver()),this,SLOT(showGGWindow()));


    enemy_count=0;




    //easy path
    QPointF e0=QPointF(1102,580);
    QPointF e1 = QPointF(1102, 80);
    QPointF e2 = QPointF(846, 80);
    QPointF e3 = QPointF(846, 530);
    QPointF e4 = QPointF(590, 530);
    QPointF e5 = QPointF(634, 80);
    QPointF e6 = QPointF(334, 80);
    QPointF e7 = QPointF(334, 530);
    QPointF e8 = QPointF(78, 530);
    QPointF e9 = QPointF(78, 20);

    patheasy.push_back(e0);
    patheasy.push_back(e1);
    patheasy.push_back(e2);
    patheasy.push_back(e3);
    patheasy.push_back(e4);
    patheasy.push_back(e5);
    patheasy.push_back(e6);
    patheasy.push_back(e7);
    patheasy.push_back(e8);
    patheasy.push_back(e9);

    //medium path
    QPointF m0 = QPointF(1120,550);
    QPointF m1 = QPointF(160, 550);
    QPointF m2 = QPointF(160, 330);
    QPointF m3 = QPointF(1120, 330);
    QPointF m4 = QPointF(1120, 110);
    QPointF m5 = QPointF(20, 110);

    pathmedium.push_back(m0);
    pathmedium.push_back(m1);
    pathmedium.push_back(m2);
    pathmedium.push_back(m3);
    pathmedium.push_back(m4);
    pathmedium.push_back(m5);

    //hard path
    QPointF h0 = QPointF(640,330);
    QPointF h1 = QPointF(480, 330);
    QPointF h2 = QPointF(480, 110);
    QPointF h3 = QPointF(1110,110);
    QPointF h4 = QPointF(1110,550);
    QPointF h5 = QPointF(160, 550);
    QPointF h6 = QPointF(160, 20);

    pathhard.push_back(h0);
    pathhard.push_back(h1);
    pathhard.push_back(h2);
    pathhard.push_back(h3);
    pathhard.push_back(h4);
    pathhard.push_back(h5);
    pathhard.push_back(h6);
}

void GameView::keyPressEvent(QKeyEvent *event){
    // if esc is pressed, close the game
    if (event->key() == Qt::Key_Escape)
    close();

    // other wise, pass keyboard event to scene which passes it to focused item (which is the player)
    QGraphicsView::keyPressEvent(event);
}

void GameView::mouseMoveEvent(QMouseEvent *event)
{
    QPointF pt1(player->getOrigin()); //change point to object from player of x/y_previous
        QPointF pt2(event->pos());
        QLineF line(pt1,pt2);
        double angle = -1 * line.angle();

        player->setRotation(angle);
        player->setAngle(angle);
}


void GameView::mousePressEvent(QMouseEvent *event)
{
    projectile* Projectile = new projectile();
    Projectile->setPos(player->getOrigin());
    Projectile->setRotation(player->getAngle());
    scene->addItem(Projectile);
}

void GameView::mouseDoubleClickEvent(QMouseEvent *event)
{

}

void GameView::addenemyeasy()
{
    enemy* Enemy = new enemy(patheasy, 1);
    Enemy->setPos(patheasy[0]);
    scene->addItem(Enemy);
    enemy_count++;
    //connect(Enemy,SIGNAL(decrease_count()),this,SLOT(check_count()));

}

void GameView::addenemymedium()
{
    enemy* Enemy = new enemy(pathmedium, 2);
    Enemy->setPos(pathmedium[0]);
    scene->addItem(Enemy);
    enemy_count++;
    //connect(Enemy,SIGNAL(decrease_count()),this,SLOT(check_count()));
}

void GameView::addenemyhard()
{
    enemy* Enemy = new enemy(pathhard, 3);
    Enemy->setPos(pathhard[0]);
    scene->addItem(Enemy);
    enemy_count++;
    //connect(Enemy,SIGNAL(decrease_count()),this,SLOT(check_count()));
}

/*void GameView::check_count()
{
    enemy_count--;
    if(enemy_count==0)
    {
        scene->clear();
    }
}
*/

void GameView::placeRocks(){

    placeRock(0,0,1280,20,0);
    placeRock(0,0,20,660,0);
    placeRock(1260,0,20,660,0);
    placeRock(0,640,1280,20,0);
}

void GameView::placeRock(int x, int y, int width, int length, int rotation){
    Rocks * rock = new Rocks();
    rock->setPos(x,y);

    rock->setRect(0,0,width,length);
    rock->setRotation(rotation);

    scene->addItem(rock);
}

void GameView::showGGWindow()
{
    scene->clear();
    QImage * img = new QImage(":/pictures/game_over.png");
    QBrush bg_brush(*img);
    scene->setBackgroundBrush(bg_brush);


}





