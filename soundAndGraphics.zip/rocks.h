#ifndef ROCKS_H
#define ROCKS_H
#include <QGraphicsRectItem>

class Rocks: public QGraphicsRectItem
{
public:
    Rocks();
};

#endif // ROCKS_H

