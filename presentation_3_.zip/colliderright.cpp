#include "colliderright.h"

ColliderRight::ColliderRight(QGraphicsItem *parent): QGraphicsRectItem(parent){

}
