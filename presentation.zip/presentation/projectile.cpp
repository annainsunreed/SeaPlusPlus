#include "projectile.h"
#include <QPixmap>
#include <QTimer>
#include <qmath.h>
#include "gameview.h"

extern GameView* game;

projectile::projectile(QGraphicsItem *parent): QObject(), QGraphicsPixmapItem(parent)
{
    setPixmap(QPixmap(":/pictures/projectile.png"));

    QTimer* fly_timer = new QTimer(this);
    connect(fly_timer,SIGNAL(timeout()), this, SLOT(fly()));
    fly_timer->start(50);
}

void projectile::fly()
{
    int step_size = 40;
    double degree = rotation();

    double dy = step_size*qSin(qDegreesToRadians(degree));
    double dx = step_size*qCos(qDegreesToRadians(degree));

    setPos(x()+dx, y()+dy);
}
